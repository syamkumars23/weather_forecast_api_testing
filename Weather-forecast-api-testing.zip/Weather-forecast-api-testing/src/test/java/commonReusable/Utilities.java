/**----------------------------------------------------------------------
Class Name: Utilities
Description: This java class suffice for all reusable & common methods/functions through our framework
and capable of extending to all open source test automation tools  
Date of Creation: 14/04/2020
Extends: NA
Implements: NA
Author: Leela, Sriram
-------------------------------------------------------------------------
Update Log: NA
Date: NA By: NA Details: NA
------------------------------------------------------------------------*/

package commonReusable;
import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class Utilities{

public static String sheetName="";
public static String scenarioName="";
public static String testCaseName = ""; 

public static HashMap<String,String> testData = new HashMap<String,String>();
public static HashMap<String, String> inputData = new HashMap<String, String>();

/**----------------------------------------------------------------------
Method Name: getData()
Description: This method is the most robust & reusable hat can support extracting required test data from different xls & csv file.

------------------------------------------------------------------------*/  

public static HashMap<String,String>getData(String excelname,String sheetName, String testCase)throws Exception{

	try {
		
		FileInputStream file = new FileInputStream(new File ("testData/"+excelname+""));	
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(file);	
		HSSFSheet sheet = workbook.getSheet(sheetName);
		
		int rowCount = sheet.getPhysicalNumberOfRows();
		int ColumnCount = sheet.getRow(0).getPhysicalNumberOfCells();
		
	System.out.println(rowCount+"*******************"+ColumnCount);

	for(int i =0; i<rowCount;i++)
	{
		if(sheet.getRow(i).getCell(0).toString().equals(testCase)&&sheet.getRow(i).getCell(1).toString().equals("Yes")){
			
			for(int k =0;k<ColumnCount;k++)
			{
				inputData.put(sheet.getRow(0).getCell(k).toString(),sheet.getRow(i).getCell(k).getStringCellValue());
			}
			break;
			
		}
	}
	file.close();
	
		
	} catch (Exception e) {
		e.getMessage();
	}
	return inputData;	
}
	

}




















