/**----------------------------------------------------------------------
Class Name: WeatherReportDefinitions
Description: This java class will collate & organize all the definitions that are to be implemented as part of 'Weather Forecast' 
Date of Creation: 10/05/2021
Extends: Internally extends to Steps java files (in built Serenity capabilities)

-----------------------------------------------------------------------*/

package definitions;
import io.cucumber.java.en.When;
import io.restassured.path.json.JsonPath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import net.thucydides.core.annotations.Steps;
import steps.WeatherReportSteps;
import java.text.DecimalFormat;
import org.apache.log4j.Logger;
import commonReusable.Utilities;



public class WeatherReportDefinitions {

	@SuppressWarnings("unused")
	private static Logger logger = Logger.getLogger(WeatherReportDefinitions.class);
	
	
    @Steps
    WeatherReportSteps weatherReportSteps;
    
   
    /**----------------------------------------------------------------------
    Method Name: getDataValues()
    Description: This method is reusable and robust one that can support all related test cases for Weather report feature
    
    ------------------------------------------------------------------------*/  
    
    @Given("^The test data is provided for '(.*)' executions$")

	public static void getDataValues(String testCaseName) throws Exception{
		try {
			
			Utilities.testData =  Utilities.getData("WeatherForecast.xls", "WeatherReport", testCaseName);
			
		} catch (Exception e) {
			
			e.getMessage();
			
		}      			
	}
    
    
    /**----------------------------------------------------------------------
    Method Name: weatherDataForALocation()
    Description: This method is used to get weather forecast for a location

    ------------------------------------------------------------------------*/   
    
    @When("^I forecast essential weather data for Sydney location$")
    public void weatherDataForALocation() {
    	weatherReportSteps.getResponse();
    }
    
    
    /**----------------------------------------------------------------------
    Method Name: captureWeatherReport()
    Description: This method is robust and reusable that can captures weather report for number of days with above 20 degrees

    ------------------------------------------------------------------------*/  
    
    @SuppressWarnings("static-access")
	@Then("^I capture the number of days where the temperature is predicated to be above 20 degrees$")
    public void captureWeatherReport() {
    	
    	try {
			
    		 JsonPath jsonPath = JsonPath.from(weatherReportSteps.response);
    	        String[] daytemp = jsonPath.getString("daily.temp.day").split(",");	        
    	          	        
    	        for (int i = 0; i < daytemp.length; i++) {   	     	        	
    	        	int tempconvert = 	Integer.parseInt(new DecimalFormat("#").format(Double.parseDouble(jsonPath.getString("daily.temp.day["+i+"]")))) ;	
    	        	 if (tempconvert >= 20) {	 			
    	        		 weatherReportSteps.captureWeatherReportWithDegreesAndDescription(jsonPath.getString("daily.temp.day["+i+"]"), jsonPath.getString("daily.weather.main["+i+"]"));
	 
    	 			}       	 
    			}	    		
    		
		} catch (Exception e) {
			e.getMessage();
		}
    	    
    }    
}
