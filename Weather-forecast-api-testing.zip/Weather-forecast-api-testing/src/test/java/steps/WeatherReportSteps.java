/**----------------------------------------------------------------------
Class Name: WeatherReportSteps
Description: This java class will collate & organize all the steps that are to be implemented as part of 'Weather Forecast' and
captures test evidences without additional piece of code, Serenity default features supports this.
Date of Creation: 10/05/2021

------------------------------------------------------------------------*/

package steps;

import java.util.Date;
import org.junit.Assert;
import commonReusable.Utilities;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.annotations.Step;

@SuppressWarnings("unused")
public class WeatherReportSteps {

	static Utilities util;
	public static int j=0;
	public static String response;
	public static String baseUrl = "https://api.openweathermap.org/data/2.5/onecall?";
	
	
	 /**----------------------------------------------------------------------
    Method Name: getData()
    Description: Method retrieve the data from the test data file
    ------------------------------------------------------------------------*/  
	
	@SuppressWarnings("static-access")
	public String getData(String getDataFor) {

	return util.testData.get(getDataFor);

	}
	
	 /**----------------------------------------------------------------------
    Method Name: getResponse()
    Description: To retrieve the api response
 
    ------------------------------------------------------------------------*/  
	
	@Step("Retrive response for the given API")
	public void getResponse() {
		try {
			SerenityRest.get(baseUrl+"lat=" + getData("lat") + "&lon="
					+ getData("lon") + "&units=" + getData("units") + "&exclude=" + getData("exclude") + "&appid="
					+ getData("appid") + "");

			  Assert.assertEquals(200, SerenityRest.lastResponse().statusCode());		  
			  	    
		      response =  SerenityRest.lastResponse().asString();
			
		} catch (Exception e) {
			e.getMessage();
		}
	}

	 /**----------------------------------------------------------------------
    Method Name: getResponse()
    Description: This method is used to capture the steps for reporting */  
	
	@Step
	public void captureWeatherReportWithDegreesAndDescription(String daytemp, String weatherMain) {
		try {
			if (weatherMain.contentEquals("[Clear]")) {	 	   	 
		   		 System.out.println("++++++++++++++" +j++);		 		 
		   		 
				}	
				numberOfSunnyDaysPredicted(j);	
			
		} catch (Exception e) {
			e.getMessage();
		}
			
	}
	
	
	@Step
	public void numberOfSunnyDaysPredicted(int j) {		
		
	}
	
			

}
